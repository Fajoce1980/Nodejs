const Registro =  (req, res)=>{
    res.send('Registro')
    };

module.exports = {
    Registro
}