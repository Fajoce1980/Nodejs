const { Pool } = require('pg');

const pool = new Pool({
    host:'localhost',
    user:'postgres',
    password:'12345',
    database:'restapi'

})

const Ver_Inventario = async (req, res)=>{
    const response = await pool.query('SELECT * FROM INVENTARIO');
    res.status(200).json(response.rows);
    };

    const CrearCompra = async (req, res)=>{
        const {numero_serie, nombre } = req.body;
        pool.query('INSERT INTO inventario(numero_serie, nombre)VALUES($1, $2),[numero_serie,nombre]');
        res.send('Producto created');
        };

        const VerCompra = async (req, res)=>{
            const response = await pool.query('SELECT *, cantidad * valor as total,cantidad * valor * 0.19 as IVA,cantidad * valor * 1.19 as Neto  FROM COMPRAS');
            res.status(200).json(response.rows);
            };

            const HistorialCompras = async (req, res)=>{
                const response = await pool.query('SELECT * FROM COMPRAS ORDER BY FECHA desc limit 1');
                res.status(200).json(response.rows);
                };

module.exports = {
    Ver_Inventario,
    CrearCompra,
    VerCompra,
    HistorialCompras
}