
const { Router } = require('express');
const router = Router();
const { Ver_Inventario} = require('../controllers/index.controller');
const { CrearCompra} = require('../controllers/index.controller');
const { VerCompra} = require('../controllers/index.controller');
const { Registro} = require('../controllers/Registro');
const { Clientes} = require('../controllers/Clientes');
const { HistorialCompras} = require('../controllers/index.controller');


router.get('/Verstock',Ver_Inventario);
router.put('/CrearCompra',CrearCompra);
router.get('/VerCompra',VerCompra);
//router.get('/Clientes',Clientes);
//router.get('/Registro',Registro);
router.get('/Historial',HistorialCompras);
module.exports = router;
