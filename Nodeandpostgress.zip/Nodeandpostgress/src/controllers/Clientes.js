const Clientes =  (req, res)=>{
    res.send('Clientes')
    };

module.exports = {
    Clientes
}