const { Pool } = require('pg');

const pool = new Pool({
    host:'localhost',
    user:'postgres',
    password:'12345',
    database:'restapi'

})

const Ver_Inventario = async (req, res)=>{
    const response = await pool.query('SELECT * FROM INVENTARIO');
    res.status(200).json(response.rows);
    };

    const CrearProducto = async (req, res)=>{
        const {numero_serie, nombre } = req.body;
        pool.query('INSERT INTO inventario(numero_serie, nombre)VALUES($1, $2),[numero_serie,nombre]');
        res.send('Producto created');
        };
        const CrearCompra = async (req, res)=>{
            const {fecha, nombre, producto, cantidad,valor } = req.body;
            pool.query('INSERT INTO COMPRAS(FECHA, CLIENTE, NOMBRE_PRODUCTO, CANTIDAD,VALOR)VALUES($1, $2,$3, $4,$5),[fecha,nombre,producto,cantidad,valor]');
            res.send('Created successfully!!!');
            };

        const VerCompra = async (req, res)=>{
            const response = await pool.query('SELECT *, cantidad * valor as total,cantidad * valor * 0.19 as IVA,cantidad * valor * 1.19 as Neto  FROM COMPRAS');
            res.status(200).json(response.rows);
            };
            const VerComprasXId = async (req, res)=>{
                const response = await pool.query('SELECT * FROM COMPRAS WHERE ID =$1',[req.params.id]);
                res.status(200).json(response.rows);
                };
                const DeleteCompra = async (req, res)=>{
                    const response = await pool.query('DELETE  FROM COMPRAS WHERE ID =$1', [req.params.id]);
                    res.status(200).json(response.rows);
                    res.send("Deleted successfully!!!")
                    };
                    const EditarCompra = async (req, res)=>{
                        const {id} = req.params.id;
                        const {fecha, nombre,producto, cantidad, valor } = req.body;
                        pool.query('UPDATE COMPRAS SET FECHA=$1, cliente =$2, nombre_producto=$3,CANTIDAD=$4, VALOR=$5 WHERE ID=$6',[
                            fecha,
                            nombre,
                            producto,
                            cantidad,
                            valor,
                            id
                        ]);
                        res.send('Updated successfully!!!');
                        };

            const HistorialCompras = async (req, res)=>{
                const response = await pool.query('SELECT * FROM COMPRAS ORDER BY FECHA desc limit 1');
                res.status(200).json(response.rows);
                };

module.exports = {
    Ver_Inventario,
    CrearProducto,
    CrearCompra,
    VerCompra,
    HistorialCompras,
    VerComprasXId,
    DeleteCompra
}