const {Pool} = require('pg');

new Pool({
    host:'loclhost',
    user:'postgress',
    password:'12345',
    database:'RESTAPI'

})

const Ver_Inventario = async (req, res)=>{
    const response = await Pool.query('SELECT * FROM INVENTARIO');
    res.status(200).json(response.rows);
    };

    const CrearCompra = async (req, res)=>{
       console.log(req.body);
        };

        const VerCompra = async (req, res)=>{
            const response = await Pool.query('SELECT * FROM COMPRA');
            res.status(200).json(response.rows);
            };

            const HistorialCompras = async (req, res)=>{
                const response = await Pool.query('SELECT TOP 5 FROM COMPRA ORDER BY FECHA_DE__COMPRA');
                res.status(200).json(response.rows);
                };

module.exports = {
    Ver_Inventario,
    CrearCompra,
    VerCompra
}