const { json } = require('express');
const express = require('express');
const app = express();

//Middlewares
app.use(express.json());
app.use(express.urlencoded({extend: false}));

app.listen(3000);

//routes
app.use(require('./routes/index'));
console.log('Conectado');