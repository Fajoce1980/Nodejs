
const { Router } = require('express');
const router = Router();
const { Ver_Inventario} = require('../controllers/index.controller');
const { CrearCompra} = require('../controllers/index.controller');
const { VerCompra} = require('../controllers/index.controller');
const { Registro} = require('../controllers/Registro');
const { Clientes} = require('../controllers/Clientes');


router.get('/Verstock',Ver_Inventario);
router.put('/CrearCompra',CrearCompra);
router.get('/VerCompra',VerCompra);
router.get('/Clientes',Clientes);
router.get('/Registro',Registro);
module.exports = router;
