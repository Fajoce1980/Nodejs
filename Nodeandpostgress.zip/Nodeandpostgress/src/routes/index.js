
const { Router } = require('express');
const router = Router();
const { Ver_Inventario, CrearProducto} = require('../controllers/index.controller');
const { Registro} = require('../controllers/Registro');
const { Clientes} = require('../controllers/Clientes');
const { HistorialCompras,CrearCompra,VerCompra, VerComprasXId, DeleteCompra} = require('../controllers/index.controller');


router.get('/Verstock',Ver_Inventario);
router.put('/CrearProducto',CrearProducto);
router.put('/CrearCompra',CrearCompra);
router.get('/VerCompra',VerCompra);
router.get('/VerCompra/:id',VerComprasXId);
router.delete('/Borrar/:id',DeleteCompra);
router.get('/Historial',HistorialCompras);
module.exports = router;
